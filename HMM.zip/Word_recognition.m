clear all;
clc;
C={'Call', 'Praveen', 'Open', 'Start', 'Camera', 'Turn', 'On', 'GPS', 'Good', 'Morning'};
disp( 'The words are: ')
for y=1:length(C)
disp (C{y});
end
disp('Speak any word from this list');


for k=1:length(C)
    x=wavread(strcat('WAV\',C{k},'-01'));
    fs=16000;
     
% II-IV Preprocessing
   z = Preprocessing(x);
   sound(z,fs);
   pause(1);
% V - Feature Extraction - MFCC Coefficients
    
   X=mfcc(z,fs,12,120);
    
% VI - HMM Model
    [Qi,Aij,Bik]=getQAB(5,2,X); % Getting model parameters
    H{k}=HMM(Qi,Aij,Bik); % Constructing HMM model
% VII - Learning Parameters
    H{k}=hmm_reestimate(H{k},X,25);
end
 disp('Training Complete');
 for a=1:10
 disp('Get ready for speaking word :');
 pause(4);
 T=zeros(1,10);
    y = recording(); % Getting real time speech input
    z = Preprocessing(y); % Preprocessing
    Y=mfcc(z,fs,12,120);  % Feature extraction - MFCC coefficients
     for n=1:length(C)
        p=hmm_probob(H{n},Y); % Calculating likelihood of observations
                              % with all HMM trained models
        M(k,n)=p;
        T(n)=abs(M(k,n)/10000);
        disp(T(n));
    end
   [~,v]=(min(T));
   
   disp('The spoken word is :');
   disp(C{v});
 end

