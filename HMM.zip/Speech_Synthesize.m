D={'Lee Byung', 'In South Korea', 'Hello', 'Subang Jaya','Hi Dr Aravind', 'Shadow', 'Apple', 'Sending email', 'Camera is ON', 'Thank you','Android OS','IT is 3 GB','In 2016','RM 1000','No I dont','Two Flights','4 pm','4 hrs delay','Texting Dr.Mun','Check Online'};

SQ = SendQuery();
disp(SQ);
instrfind;
delete(instrfind);
sObject=serial('COM3','BaudRate',9600, 'TimeOut',5, 'Terminator', 'LF');


 fopen(sObject);

 
rec=fgets(sObject);
a=rec(1);
N=uint8(a);
disp(N);
tts(D{N},[],-1,16000);
fclose(sObject);


