function SQ = SendQuery()

str=Speech_to_text();

instrfind;
delete(instrfind);
sObject=serial('COM3','BaudRate',9600, 'TimeOut',10, 'Terminator', 'LF');


 fopen(sObject);
% for i=1:n
fwrite(sObject,str);


fclose(sObject);
SQ = 'Send Successfull';